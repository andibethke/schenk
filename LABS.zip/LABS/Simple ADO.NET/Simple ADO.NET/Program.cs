﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using MyTools;
using Simple_ADO.NET.Models;
using System.Runtime.CompilerServices;
using System.Transactions;

Console.WriteLine("Simple ADO.NET!");


string s = "123";
Console.WriteLine($"erg: {"123".ToZahl()*2}" );

//UsingSimpleConnections();
UsingEF();

async void UsingEF()
{
	using (var trans = new TransactionScope())
	{

        using (var ctx = new NORTHWNDContext())
        {
            var k = new Product()
            {
                //ProductId=1001,
                ProductName = "Klaus"
            };

            ctx.Products.Add(k);

            Console.WriteLine($"ID: {k.ProductId}");
            await ctx.SaveChangesAsync();
            Console.WriteLine($"ID: {k.ProductId}");

            k = ctx.Products.Single(x => x.ProductId == k.ProductId);
            k.UnitPrice = 1000;
            ctx.SaveChanges();

            foreach (var p in ctx.Products.Where(x => x.ProductName.StartsWith("K")))
            {
                Console.WriteLine($"{p.ProductName}");
            }

            foreach (var c in ctx.Categories.Include("Products"))
            {
                Console.WriteLine($"{c.CategoryName}");
                foreach (var p in c.Products)
                {
                    Console.WriteLine($"\t{p.ProductName}");
                }
            }
        }

        

        trans.Complete();

    }
}

void UsingSimpleConnections()
{
	using (var con=new SqlConnection("Data Source=LAPPI8;Initial Catalog=NORTHWND;Integrated Security=true"))
	{
		con.Open();
		using var cmd=con.CreateCommand();
		cmd.CommandText = "select * from products";
		using var rdr=cmd.ExecuteReader();
		while (rdr.Read())
		{
			Console.WriteLine($"{rdr["productname"]}");
		}
	}
}


//Scaffold-DbContext "Data Source=LAPPI8;Initial Catalog=NORTHWND;Integrated Security=true" Microsoft.EntityFrameworkCore.SqlServer -o Models -f -tables PRODUCTS,CATEGORIES,TOP5Cust

namespace MyTools
{
	public static class Tools
	{
		public static int ToZahl(this string s)
		{
			int i = 0;
			int.TryParse(s, out i);
			return i;
		}
	}
}
