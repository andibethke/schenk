﻿using System;
using System.Collections.Generic;

namespace Simple_ADO.NET.Models
{
    public partial class Top5cust
    {
        public string CompanyName { get; set; } = null!;
        public decimal? Summe { get; set; }
    }
}
