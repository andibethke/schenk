﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BmiClient.Models
{

    public class Person
    {
        public int goesse { get; set; }
        public int gewicht { get; set; }
        public float bmi { get; set; }
        public bool isOk { get; set; }
    }

}
