﻿using BmiClient.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BmiClient.ViewModels
{
    public class PersonVM : INotifyPropertyChanged, ICommand
    {
        public Person Person { get; set; } = new Person();

        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            LoadData();
        }

        public async void LoadData()
        {
            using (var http=new HttpClient() { BaseAddress=new Uri("https://localhost:7230/") })
            {
                var res =await http.GetAsync($"/person/?gr={Person.goesse}&gew={Person.gewicht}"); 
                var json=await res.Content.ReadAsStringAsync();
                Person = System.Text.Json.JsonSerializer.Deserialize<Person>(json);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(""));
            }
        }
    }
}
