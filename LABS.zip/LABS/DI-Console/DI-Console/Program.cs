﻿// See https://aka.ms/new-console-template for more information
using DI_Console;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;

Console.WriteLine("Hello, World!");


var serviceProvider = new ServiceCollection()
            .AddLogging(c=>c.AddConsole())
            .AddTransient<IFooService, FooService>()
            .AddTransient<IBarService, BarService>()
            .BuildServiceProvider();



//configure console logging
//serviceProvider
//    .GetService<LoggerFactory>()
//    .CreateLogger<Program>();

var logger = serviceProvider.GetService<ILoggerFactory>()
    .CreateLogger<Program>();
logger.LogDebug("Starting application");

//do the actual work here

for (int i = 0; i < 10; i++)
{
    var bar = serviceProvider.GetService<IBarService>();
    bar.DoSomeRealWork();

}
logger.LogDebug("All done!");