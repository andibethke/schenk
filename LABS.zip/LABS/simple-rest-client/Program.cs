﻿// See https://aka.ms/new-console-template for more information
using System.Text;
using System.Text.Json;

Console.WriteLine("Hello, World!");


//autorest --input-file=.swagger.json --v3 --csharp --use-datetimeoffset=true --output-folder=./SimpleApi.Client --namespace=SimpleApi.Client


for (int i = 0; i < 50; i++)
{
     await PostData(i);
}
await GetData();


async Task PostData(int nr)
{
    using var http=new HttpClient(){BaseAddress=new Uri("https://schenck.azurewebsites.net")}
    
    using var person=new Root(){FirstName="Nummer "+nr, LastName="sdgfsdf"};
    var json=JsonSerializer.Serialize(person);
    System.Console.WriteLine(   json);
    var content = new StringContent(json, Encoding.UTF8, "application/json");
    var res=await http.PostAsync("student",content);
    System.Console.WriteLine( res.ReasonPhrase);

}
async Task GetData()
{
    using (var http=new HttpClient(){BaseAddress=new Uri("https://schenck.azurewebsites.net")})
{
    var res=await http.GetAsync("student");
    if (res.IsSuccessStatusCode)
    {
        var json=await res.Content.ReadAsStringAsync();
        var data=JsonSerializer.Deserialize<Root[]>(json);
        foreach (var item in data)
        {
            System.Console.WriteLine($"{item.Id} - {item.FirstName} {item.LastName}  " );
        }
    }
}

}

public class Root : IDisposable
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

    public void Dispose()
    {
        throw new NotImplementedException();
    }
}
