﻿namespace Simple_rest_services.MiddleWare
{
    public class MyMiddleware
    {
        private readonly RequestDelegate next;
        public MyMiddleware(RequestDelegate next)
        {
            this.next = next;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            
            var path = context.Request.Path;
            await next(context);
           // var res=context.Response.Body.;
        }
    }
}
