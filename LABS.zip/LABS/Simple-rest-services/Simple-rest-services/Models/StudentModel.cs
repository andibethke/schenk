﻿namespace Simple_rest_services.Models
{
    public class StudentModel
    {
        public static List<StudentModel> Students=new List<StudentModel>();

        static StudentModel()
        {
            Students.Add(new StudentModel()
            {
                Id = 1,
                FirstName = "Bart",
                LastName = "Simpson"
            });
        }
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
