﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Simple_rest_services.Filters;
using Simple_rest_services.Models;

namespace Simple_rest_services.Controllers
{

    [Route("[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private StudentModel _student;

        public StudentController(StudentModel student)
        {
            _student = student;
        }

        [HttpGet]
        [MyActionFilter]
        public ActionResult<StudentModel[]> Get()
        {
            return Ok(StudentModel.Students);
        }

        [HttpPost]
        public ActionResult<StudentModel[]> Post([FromBody] StudentModel data)
        {
            StudentModel.Students.Add(data);
            return Ok(StudentModel.Students);
        }
        [HttpDelete]
        
        public IActionResult Delete( int id)
        {
            var str = StudentModel.Students.SingleOrDefault(x => x.Id == id);
            if (str==null)
            {
                return Problem("ID Unknown, Alter!");
            }
            StudentModel.Students.Remove(str);
            return Ok(StudentModel.Students);
        }
    }
}
