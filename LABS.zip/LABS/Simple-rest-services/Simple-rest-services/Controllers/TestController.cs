﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Simple_rest_services.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        [HttpGet]
        public ActionResult<Mensch> Berechne([FromQuery]Mensch m)
        {
            return Ok(m);
        }
    }

    public class Mensch
    {
        public double Gr { get; set; }
        public double Gew { get; set; }
        public double Bmi => Gew / (Gr * Gr);
    }
}
