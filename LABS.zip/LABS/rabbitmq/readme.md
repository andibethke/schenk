docker run -d -p 5672:5672 --hostname my-rabbit --name my-rabbit rabbitmq:3

docker run -d -p 5672:5672 -p 8080:15672 --hostname my-rabbit --name my-rabbit rabbitmq:3-management