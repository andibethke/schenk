﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace db_depper.Models
{
    public class Person
    {
        public int Id { get; set; }
        public string vorname { get; set; }
        public string nachname { get; set; }
    }
}
