﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using De.Schenck.Bmi.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De.Schenck.Bmi.Business.Tests
{
    [TestClass()]
    public class PersonTests
    {
        [TestMethod()]
        public void PersonTest()
        {
            Assert.AreEqual(27.46, new Person() { Weight = 95, Height = 1.86 }.Bmi);
        }
    }
}