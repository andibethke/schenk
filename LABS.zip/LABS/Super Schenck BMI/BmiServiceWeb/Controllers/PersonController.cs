﻿using De.Schenck.Bmi.Business;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BmiServiceWeb.Controllers
{
    [Route("person")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get(double gr, double gew)
        {
            var p = new Person() { Height = gr, Weight = gew };
            return Ok(new {goesse=p.Height, gewicht=p.Weight, Bmi=p.Bmi, p.IsOk });
        }
    }
}
