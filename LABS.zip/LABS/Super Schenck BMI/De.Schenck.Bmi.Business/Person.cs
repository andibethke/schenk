﻿namespace De.Schenck.Bmi.Business
{
    public class Person
    {
        public Person()
        {

        }
        public double Weight { get; set; }
        public double Height { get; set; }

        public double Bmi => Math.Round( Weight / (Height * Height),2);
        public bool IsOk => Bmi >= 19 && Bmi <= 24;
    }
}